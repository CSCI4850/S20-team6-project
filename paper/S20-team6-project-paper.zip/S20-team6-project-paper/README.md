# S20-team6-project
## Internal Team Name - Team GIG
### Members
1. George Boktor 
2. Nibraas Khan
3. Ruj Haan
4. Michael McComas
5. Ramin Daneshi
6. Brandon Swenson

This repository contains the work for cracking Steganography algorithm for the Spring 2020 Neural Networks class. 
